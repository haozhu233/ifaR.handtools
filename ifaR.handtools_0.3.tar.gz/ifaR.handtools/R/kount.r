#' kount
#' @author TGT
#' @export

kount<-function(a){(length(unique(a)))}